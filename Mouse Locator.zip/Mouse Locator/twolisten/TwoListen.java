/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twolisten;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.MouseListener;
 
   public class TwoListen implements MouseMotionListener, MouseListener{
    private TextField tf;
    private Frame f;
    
    public TwoListen() {
        f = new Frame("Two MouseListener Example");
        f.add(new Label("Click and Drag the Mouse"), BorderLayout.NORTH);
        tf = new TextField(30);
        f.add(tf, BorderLayout.SOUTH);
        f.addMouseMotionListener(this);
        f.addMouseListener(this);
        f.setSize(300, 200);
        
        WindowListener listener = new WindowListener() {
            
              @Override
              public void windowOpened(WindowEvent e) {}
              @Override
              public void windowClosing(WindowEvent e) {}
              @Override
              public void windowClosed(WindowEvent e) {}
              @Override
              public void windowIconified(WindowEvent e) {}
              @Override
              public void windowDeiconified(WindowEvent e) {}
              @Override
              public void windowActivated(WindowEvent e) {}
              @Override
         public void windowDeactivated(WindowEvent e) {}
            };
        f.addWindowListener(listener);
        f.setVisible(true);
            }
    
       public void mouseDragged(MouseEvent e){
             String s = "Mouse dragging: X = " + e.getX() + "Y = "+e.getY();
              tf.setText(s);
               }
       public void mouseEntered(MouseEvent e){
               String s = "The Mouse Entered";
               tf.setText(s);
               }
        public void mouseExited(MouseEvent e){
            String s = "The Mouse has lest the Building";
            tf.setText(s);
         }
        
  public void mouseMoved(MouseEvent e){}
  public void mouseReleased(MouseEvent e){}
  public void mouseClicked(MouseEvent e){}
  public void mousePressed(MouseEvent e){}
  public static void main(String[]args){
   TwoListen two = new TwoListen();
 }


}
