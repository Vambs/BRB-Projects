package teststrategy;
//Number 1: interface named Payment
interface Payment {
//Number 2: void method for the interface named pay
 public void pay(double amount);
}
//Number 3: I created a class named Online that implements Payment; with two (2) private String variables named email and password.
class Online implements Payment {
 private String email;
 private String password;
 //Number 4: I add two (2) String parameters named email and password.
 Online (String email, String password) {
//Number 5: I copy the code in the intructions and insert it into my constructor.
 this.email = email;
 this.password = password;
 }
//Number 6: I use the pay method from my interface and I copy the code in the intructions.
 public void pay(double amount) {
 System.out.println("Paid using online account: " + amount);
 }
}
//Number 7: I create a class named Mobile that implements Payment and I declare two private variables named number (String) and pin (int).
class Mobile implements Payment {
 private String number;
 private int pin;
 //Number 8: I add two parameters named number and pin.
 Mobile (String number, int pin) {
 //Number 9: I Insert two(2) this statements into my constructor.
 this.number = number;
 this.pin = pin;
 }
 //Number 10: I use the pay method again and edit the display message.
 public void pay(double amount) {
 System.out.println("Paid using mobile wallet: " + amount);
 }
}
//Number 11: I add the class named Cart and I declare a private double variable named amount.
class Cart {
 private double amount;
 //Number 12: I add a double parameter to its constructor. Then, write a this statement.
 Cart (double amount) {
 this.amount = amount;
 }
 //Number 13: I add a pay method and copy the code from the Intructions.
 public void pay(Payment mode) {
 mode.pay(amount);
 }
}
//Number 14 and 15: Using TestStrategy to execute the code and I instantiate a Cart object named cart which I copy from the Instructions
public class TestStrategy {
 public static void main(String...args) {
 Cart cart = new Cart(1512.75);
 //For the First output
 cart.pay(new Online("Bambi.Berja@gmail.com", "Vambs123!"));
 cart = new Cart(375.25);
 //For the Second output
 cart.pay(new Mobile("09123456789", 123456));
 }
}
