package fruitbasket;
import java.util.Stack;
import java.util.Scanner;

public class FruitBasket {

    public static void main(String[] args) {
        Stack<String> basket = new Stack<>();
        Scanner input = new Scanner(System.in);    

        System.out.println("Catch and eat any of these fruits:('Apple', 'Orange', 'Mango' , 'Guava')");
        System.out.print("How many fruits would you like to catch? ");
        int num = input.nextInt();

        for (int i = 1; i <= num; i++) {
            System.out.print("Choose a fruit to catch. Press A, M, O, or G: ");
            char choose = input.next().charAt(0);
            choose = Character.toUpperCase(choose);
            System.out.println("Fruit " + i + " of " + num + ":");

            switch (choose) {
                case 'A':
                    basket.push("Apple");
                    break;
                case 'M':
                    basket.push("Mango");
                    break;
                case 'O':
                    basket.push("Orange");
                    break;
                case 'G':
                    basket.push("Guava");
                    break;
                default:
                    System.out.println("Invalid choice");
                    i--; // to allow retry in case of invalid input
                    break;
            }
        }

        System.out.println("Your basket now has: " + basket);

        for (int i = 1; i <= num; i++) {
            if (basket.isEmpty()) {
                System.out.println("No more fruits");
                break;
            }
            System.out.print("Press E to eat a fruit: ");
            char e = input.next().charAt(0);
            e = Character.toUpperCase(e);

            if (e == 'E') {
                basket.pop();
            } else {
                System.out.println("Invalid input, press E to eat.");
                i--; // retry if invalid input
                continue;
            }
            System.out.println("Fruit(s) in the basket: " + basket);
        }

        if (basket.isEmpty()) {
            System.out.println("No more fruits");
        }
    }
}
