
package schoolchatbox;
import java.util.*;
import java.util.ArrayList;
public class SchoolChatbox {

    public static void main(String[] args)throws InterruptedException {
        
        Scanner input= new Scanner(System.in);
         System.out.print(" What's your name? ");
         String name=input.nextLine();
          Thread.sleep(2000);  
        System.out.print("Good day " +name+"! Welcome to STI student support how can I help you?");
        System.out.print(" \nA. Student account B. Tuition Fee C. Services ");
        Thread.sleep(2000);
        ArrayList choices =new ArrayList();
        choices.add(" A. Students account");
        choices.add(" B. Tuition Fee");
        choices.add(" C. Services");
        String help=input.nextLine();
        if  (help.equalsIgnoreCase("choices"))
         System.out.println("Hi to assist you further with your concern,");
        else
           System.out.print("Hi to assist you further with your concern,");
           Thread.sleep(2000);
           System.out.print("\nkindly provide the following:student name, student id and Course & Year level:(seperated by space)");
           String stn=input.nextLine();
        System.out.print("\nThanks for your message " +name+ ",");
        System.out.print("\nWe will update you on your concern once an officer becomes available.");
        System.out.print("\nOur school operation starts at 8 am until 5 pm Mondays to Saturdays.");
    }
    }
