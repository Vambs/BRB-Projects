function startTimer(){
    isPaused = false; }
function pauseTimer(){
    isPaused = true;
}
function resetTimer() {
    countdownTimerElementDisplay.textContent = '10:00';
    time = startingMinutes * 60;
    isPaused = true;
}
class Countdown {
    constructor() {
    this.duration = 0;
    this.elapsed = 0;
    this.isActive = false;
    this.lastFrameTime = Date.now();
    this.onTick = () => {};
    this.onCompleted = () => {};
    this.tick();
}
   getTimeLeft() {
    const t = this.duration - this.elapsed;
    return Math.max(0, t);}
    pause() {
     this.isActive = false;
     return this;
    }
    reset() {
     this.elapsed = 0;
    }
      setDuration(seconds) {
        this.lastFrameTime = Date.now();
         this.duration = seconds;
        return this; }
      start() {
        this.isActive = true;
        return this;}
      tick() {
        const currentFrameTime = Date.now();
        const deltaTime = currentFrameTime - this.lastFrameTime;
        this.lastFrameTime = currentFrameTime;
        if (this.isActive) {
          this.elapsed += deltaTime / 1000;
          this.onTick(this.getTimeLeft());
          if(this.getTimeLeft() <= 0) {
            this.pause();
            this.onCompleted();
          }
        }
        window.requestAnimationFrame(this.tick.bind(this));
      }
    }
    const countdown2 = new Countdown().setDuration(15);
    const label2 = document.querySelector('.time2');
    
    document.querySelector('.pause2').addEventListener('click', () => {
      countdown2.pause();
});
    document.querySelector('.reset2').addEventListener('click', () => {
      countdown2.reset();
      label2.innerHTML = Math.ceil(countdown2.getTimeLeft());
});
    document.querySelector('.start2').addEventListener('click', () => {
      countdown2.start();
});
    countdown2.onTick = (time) => {
      label2.innerHTML = Math.round(time);};
    countdown2.onCompleted = () => {
    console.log('DONE');
};
    const countdown = new Countdown().setDuration(24);
    const label = document.querySelector('.time');
    document.querySelector('.pause').addEventListener('click', () => {
    countdown.pause();
});
    document.querySelector('.reset').addEventListener('click', () => {
      countdown.reset();
      label.innerHTML = Math.ceil(countdown.getTimeLeft());
});
    document.querySelector('.start').addEventListener('click', () => {
    countdown.start();
}); 
    countdown.onTick = (time) => {
    label.innerHTML = Math.round(time);
}; 
    countdown.onCompleted = () => {
      console.log('DONE');
};
    const countdown3 = new Countdown().setDuration(60*10);
    const label3 = document.querySelector('.time3');
    countdown3.onTick = (time) => {
      label3.innerHTML = Math.round(time);
};
    countdown3.onCompleted = () => {
      console.log('DONE');
};
  let countdownTimerElementDisplay = document.getElementById('timer_count');
  const startingMinutes = 10;
  let time = startingMinutes * 60;
  let isPaused = true;
  var timer = setInterval(() => {
      if(!isPaused) {
    const minute = Math.floor(time / 60);
    let seconds = time % 60;
    seconds = seconds < 10 ? '0' + seconds : seconds;
    countdownTimerElementDisplay.textContent = `${minute}:${seconds}`;
    time--;
}}, 1000);

function ptone() {
    var element = document.getElementById('addt1');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('addt1').innerHTML = value;
}
  function mone() {
    var element = document.getElementById('addt1');
    var value = element.innerHTML;
    --value;
    console.log(value)
    document.getElementById('addt1').innerHTML = value;
}
  function pthree() {
    var element = document.getElementById('addt1');
    var value = element.innerHTML;
    value = parseInt (value) + 3;
    console.log(value)
    document.getElementById('addt1').innerHTML = value;
}
  function reset(){  
    document.getElementById('addt1').innerHTML = 0; 
} 
  function addt2() {
    var element = document.getElementById('scoret2');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('scoret2').innerHTML = value;
}
  function addt3() {
    var element = document.getElementById('scoret2');
    var value = element.innerHTML;
    value = parseInt (value) + 3;
    console.log(value)
    document.getElementById('scoret2').innerHTML = value;
}
  function addt4() {
    var element = document.getElementById('scoret2');
    var value = element.innerHTML;
    --value;
    console.log(value)
    document.getElementById('scoret2').innerHTML = value;
}                   
  function timeoutt1() {
    var element = document.getElementById('timeoutnum1');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('timeoutnum1').innerHTML = value;
}
 function foult1() {
    var element = document.getElementById('foulnum1');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('foulnum1').innerHTML = value;
}
function periodsbt() {
    var element = document.getElementById('periodnumbt');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('periodnumbt').innerHTML = value;
}
function foult2() {
    var element = document.getElementById('foulnumt2');
    var value = element.innerHTML;
    ++value;
    console.log(value)
    document.getElementById('foulnumt2').innerHTML = value;
}
    function timeoutt2() {
      var element = document.getElementById('timeoutnum2');
      var value = element.innerHTML;
      ++value;
      console.log(value)
      document.getElementById('timeoutnum2').innerHTML = value;
}
function reset1(){   
    document.getElementById('scoret2').innerHTML = 0;
} 
    function reset2(){   
    document.getElementById('timeoutnum1').innerHTML = 0;
} 
    function reset3(){     
    document.getElementById('timeoutnum2').innerHTML = 0;
} 
    function reset4(){    
    document.getElementById('periodnumbt').innerHTML = 0;
} 
    function reset5(){     
    document.getElementById('foulnum1').innerHTML = 0;
} 
    function reset6(){  
    document.getElementById('foulnumt2').innerHTML = 0;
} 
   