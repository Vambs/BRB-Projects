import java.util.*;
import java.io.*;

public class TaskPerf6 {

    private static final String filePath = "userdata.txt";
    private static final String delimiter = ",";

    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        try {
            boolean successfulLogin = false;
            int loginAttempts = 0;
            
            while (!successfulLogin && loginAttempts < 3) {
                System.out.println("Do you want to Register or Login?");
                String userInput = scan.nextLine();

                if (userInput.equals("Register")) {
                    registerUser(scan);
                } else if (userInput.equals("Login")) {
                    successfulLogin = loginUser(scan);
                    if (!successfulLogin) {
                        loginAttempts++;
                        System.out.println("Wrong username or password. Attempts remaining: " + (3 - loginAttempts));
                    }
                } else {
                    System.out.println("Choose between Register or Login ");
                }
            }
            
            if (!successfulLogin) {
                System.out.println("Maximum login attempts reached. Exiting...");
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            scan.close();
        }
    }

    private static void registerUser(Scanner scan) throws IOException {
        BufferedWriter file = new BufferedWriter(new FileWriter(filePath, true));
        
        System.out.println("Enter username (Input should only be alphanumeric characters)");
        String userName = scan.nextLine();

        if (!userName.matches("[a-zA-Z0-9]+")) {
            file.close();
            throw new InvalidExceptionLogin("Invalid username format");
        }

        System.out.println("Enter password (Input should only be alphanumeric characters)");
        String userPassword = scan.nextLine();

        if (!userPassword.matches("[a-zA-Z0-9]+")) {
            file.close();
            throw new InvalidExceptionLogin("Invalid password format");
        }

        file.write(userName);
        file.write(delimiter);
        file.write(userPassword);
        file.newLine();
        file.close();
        System.out.println("Registration successful!");
    }

    private static boolean loginUser(Scanner scan) throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;

        System.out.println("Enter username (Input should only be alphanumeric characters)");
        String userNameLogin = scan.nextLine();

        System.out.println("Enter password (Input should only be alphanumeric characters)");
        String userPasswordLogin = scan.nextLine();

        while ((line = reader.readLine()) != null) {
            String[] userDataArray = line.split(delimiter);
            if (userDataArray.length == 2 && userDataArray[0].equals(userNameLogin) && userDataArray[1].equals(userPasswordLogin)) {
                System.out.println("Congrats you have successfully logged in");
                reader.close();
                return true;
            }
        }
        
        reader.close();
        return false;
    }

    private static class InvalidExceptionLogin extends RuntimeException {
        public InvalidExceptionLogin(String message) {
            super(message);
        }
    }
}
