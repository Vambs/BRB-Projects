package payrollprogram;
import java.util.Scanner;

 class Employee {
    private String name;
    public void setName(String newname){
        this.name= newname;
  }
    public String getName(){
        return name;   
  }
 }  
  class FullTimeEmployee extends Employee {
    private double monthlySalary;
    public void setMonthlySalary(double newSalary) {
        this.monthlySalary = newSalary;
    }
         public double getSalary () {
         return monthlySalary;
    }
  }
   class PartTimeEmployee extends Employee {
     double ratePerHour, wage ;
     int hoursWorked;
     public void setWage(double rate, int hours){
          ratePerHour = rate;
          hoursWorked = hours;
          wage = ratePerHour * hoursWorked;
    }
          public double getWage() {
          return wage;
    }
} 
    public class RunEmployee{
       public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
            System.out.println("Enter name:");
            String name= input.nextLine();
            System.out.println("Press P(PartTime)/F(FullTime)");
            char employment = input.next().charAt(0);
            
        
        if (employment == 'P') {
           PartTimeEmployee obj = new PartTimeEmployee();
            System.out.println("Enter the rate per and hour Worked seperated by space:");
            double ratePerHour =input.nextDouble();
            int numberOfHours= input.nextInt();
           
            obj.setName(name);
            obj.setWage(ratePerHour,numberOfHours);
             
             System.out.println("Employee Name:" + obj.getName());
             System.out.printf("Wage: %.2f", obj.getWage());
    
        } else if(employment == 'F') {
             FullTimeEmployee obj = new FullTimeEmployee();
            System.out.println("Enter Your Monthly Salary");
            double monthlySalary =input.nextDouble();
             obj.setName(name);
             obj.setMonthlySalary(monthlySalary);
            System.out.println("Employee Name:" + obj.getName());
            System.out.print("Employee monthly  Salary is: " +obj.getSalary());
        }
    }
    }