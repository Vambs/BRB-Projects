const output = document.querySelector(".output");
const result = document.querySelector(".result");
const keys = document.querySelectorAll("button");
keys.forEach(keys=>{    keys.addEventListener("click",calculate);});

function calculate(){
    let buttonText = this.innerText;
    if(buttonText =="AC"){
        output.innerText="";
        result.innerText ="0";
        return;
       }
   if(buttonText =="DEL"){ output.textContent=output.textContent.slice(0,-1);
     result.innerText ="";
     return;
    } 
 try{
      if(buttonText =="="){
        result.innerText= eval(output.innerText);
      }else{
         output.textContent += buttonText;
         return;
}
}catch{
 result.innerText='Error!';
}
}
  
  
