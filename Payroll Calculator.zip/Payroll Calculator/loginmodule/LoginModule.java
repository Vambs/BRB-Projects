package loginmodule;

public class LoginModule {
     public static void main(String[] args) {
        LoginUserForm login = new LoginUserForm();
        login.setForm();
    }
}
